SHIVA NUMBERDAR — Website package
=================================

Files:
- index.html
- assets/shiva-numberdar.png

Publish with the existing GitHub repository:
1. Open https://github.com/Shiva79066/shiva-numberdar
2. Choose Add file → Upload files.
3. Upload index.html and the assets folder (including shiva-numberdar.png).
4. Commit the files to the main branch.
5. Open Settings → Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select Branch: main and Folder: /(root), then Save.
8. After GitHub Pages finishes publishing, open:
   https://shiva79066.github.io/shiva-numberdar/

The site is a static, mobile-friendly website and does not need a paid hosting plan.
